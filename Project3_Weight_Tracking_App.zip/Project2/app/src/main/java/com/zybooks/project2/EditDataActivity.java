package com.zybooks.project2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditDataActivity extends AppCompatActivity {

    private static final String TAG = "EditDataActivity";

    private Button saveBtn, deleteBtn;
    private EditText editable_item;

    WeightDBHelper mDatabaseHelper;

    private String selectedItem1;
    private String selectedItem2;
    private int selectedID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_data_layout);

        saveBtn = findViewById(R.id.saveBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        editable_item = findViewById(R.id.editable_item);
        mDatabaseHelper = new WeightDBHelper(this);

        // Get the intent extras from the ListDataActivity
        Intent receivedIntent = getIntent();

        // Now get the itemID that was passed as an extra
        selectedID = receivedIntent.getIntExtra("id", -1);

        // Now get the current weight and goal weight passed as an extra
        selectedItem1 = receivedIntent.getStringExtra("Current Weight");
        selectedItem2 = receivedIntent.getStringExtra("Goal Weight");

        // Set the text to show the current selected weights
        editable_item.setText(selectedItem1);
        editable_item.setText(selectedItem2);

        // Edit the current weight
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = editable_item.getText().toString();
                if(!item.equals("")) {
                    mDatabaseHelper.updateWeight(item, selectedID, selectedItem1);
                } else {
                    Toast.makeText(EditDataActivity.this,
                            "You must enter your weight", Toast.LENGTH_LONG).show();
                }
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseHelper.deleteWeight(selectedID, selectedItem1);
                editable_item.setText("");
                Toast.makeText(EditDataActivity.this,
                        "Removed from database", Toast.LENGTH_LONG).show();
            }
        });
    }
}
