package com.zybooks.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListDataActivity extends AppCompatActivity {

    private static final String TAG = "ListDataActivity";
    private ListView mListView;
    WeightDBHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_data);

        mListView = (ListView) findViewById(R.id.listView);
        mDatabaseHelper = new WeightDBHelper(this);

        populateListView();
    }

    private void populateListView() {
        Log.d(TAG, "populateListView: Displaying data in the ListView");

        // Get the data and add to list
        Cursor data = mDatabaseHelper.getData();
        ArrayList<String> listData = new ArrayList<>();
        while(data.moveToNext()) {
            // Get the value from the db in col1 and col2
            listData.add(data.getString(1));
            listData.add(data.getString(2));
        }
        // Create list adapter and set adapter
        ListAdapter adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, listData);
        mListView.setAdapter(adapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currWeight = adapterView.getItemAtPosition(i).toString();
                String goalWeight = adapterView.getItemAtPosition(i).toString();

                // get the id associated with that curr/goal weight
                Cursor data = mDatabaseHelper.getItemID(currWeight, goalWeight);

                int itemID = -1;
                while(data.moveToNext()) {
                    itemID = data.getInt(0);
                }
                if(itemID > -1) {
                    Log.d(TAG, "onItemClick: The ID is: " + itemID);
                    Intent editScreenIntent = new Intent(ListDataActivity.this, EditDataActivity.class);
                    editScreenIntent.putExtra("id", itemID);
                    editScreenIntent.putExtra("Current Weight", currWeight);
                    editScreenIntent.putExtra("Goal Weight", goalWeight);
                    startActivity(editScreenIntent);
                } else {
                    Toast.makeText(ListDataActivity.this,
                            "No ID associated with that weight", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}