package com.zybooks.project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private final int SEND_SMS_PERMISSION_CODE = 1;
    ConstraintLayout layoutList;
    Button buttonAdd, notifyBtn, addWeights;
    WeightDBHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        layoutList = findViewById(R.id.layout_list);
        buttonAdd = findViewById(R.id.addBtn);
        notifyBtn = findViewById(R.id.notifyBtn);
        mDatabaseHelper = new WeightDBHelper(this);

        buttonAdd.setOnClickListener(view -> addView());

        // Receive SMS notification
        notifyBtn.setOnClickListener(view -> {
            if(ContextCompat.checkSelfPermission(HomeActivity.this,
                    Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(HomeActivity.this,
                        "You have already granted this permission", Toast.LENGTH_LONG).show();
            } else {
                requestSendSmsPermission();
            }
        });
    }

    /* Start Menu Functionality */
    // Make the menu button open (inflate) to display hidden option
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    // Checks for what menu option is selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Logout method
    public void logout() {
        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
    /* End Menu Functionality */

    // Add new current weight and goal weight inputs
    private void addView() {
        final View weightView = getLayoutInflater().inflate(R.layout.row_add_weight, null, false);
        EditText editText = weightView.findViewById(R.id.editCurrentWeight);
        EditText editText2 = weightView.findViewById(R.id.editGoalWeight);
        ImageView imageClose = weightView.findViewById(R.id.image_remove);

        // if new entries are not empty, add to the weight db
        String newEntry = editText.getText().toString();
        String newEntry2 = editText2.getText().toString();
        if(editText.length() != 0 && editText2.length() != 0) {
            addData(newEntry, newEntry2);
        } else {
            Toast.makeText(this, "You must add something in the text field(s)",
                    Toast.LENGTH_SHORT).show();
        }

        // If user wants to delete entry click the 'x' icon
        imageClose.setOnClickListener(view -> removeView(weightView));

        layoutList.addView(weightView);
    }

    // Delete inputs
    private void removeView(View view) {
        layoutList.removeView(view);
    }

    /*Start SMS Permissions */
    private void requestSendSmsPermission() {
        if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("Would you like to be notified when you reach your goal?")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(HomeActivity.this, new String[] {
                                    Manifest.permission.SEND_SMS},
                                    SEND_SMS_PERMISSION_CODE);
                        }
                    }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},
                    SEND_SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SEND_SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    /* End SMS Permissions */

    // Add data to weight database
    public void addData(String currWeight, String goalWeight) {
        boolean insertWeightData = mDatabaseHelper.addData(currWeight, goalWeight);

        if (insertWeightData) {
            Toast.makeText(this, "Data Successfully Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
        }
    }
}